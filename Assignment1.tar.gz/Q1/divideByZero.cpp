#include <iostream>

int main() {
    int x = 5/ 0;
    std::cout << x << std::endl;
    return 0;
}
